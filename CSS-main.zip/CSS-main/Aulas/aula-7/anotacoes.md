# 7- background - Parte 4

link: http://cfbcursos.com.br/css3-7-2-metapropriedade-background/

```css
body {
    background: #2b2b2b url(Imagem2.jpg) no-repeat center 0px / 400px;
    background: #2b2b2b url(Imagem2.jpg) no-repeat 10px 0px / 400px
}
```

1- Cor 2- URL 3- Repeticao 4- Posição 5- Tamanho