# 1- Inserindo CSS na página HTML

[link](http://cfbcursos.com.br/css3-1-1-inserindo-codigo-css-na-pagina/)
[link 2](http://cfbcursos.com.br/css3-1-2-a-sintaxe-de-uso-do-css-como-usar-o-css/)

3 Formas, a melhor é a primeira css Externo

1- Css Externo:

Ele é inserido no head


```html
    <link rel="stylesheet" href="style.css" />   <!--CSS Externo-->

```

2- Css Incorporado:

Ele é inserido no head


```html
     <!--CSS Incorporado-->
       <style>
       </style>

```

3- Css Inline: 

Ele é inserido na tag que eu quero formatar através da propriedade style


```html
     <!--CSS Inline-->
      <div style="background-color: #000;"></div>
```