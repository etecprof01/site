# 9- bordas (border) - Parte 2

link: http://cfbcursos.com.br/css3-8-bordas-border/

````
p {
   border-top: #1a7dff solid 5px;
   border-right: #ddff1a solid 10px;
   border-left: #ff1a1a solid 10px;
   border-bottom: #2dff1a solid 5px;
   border-radius: 10px;

   /*
   Também é possivel fazer isso:

   border-top-style: solid;
   border-right-color: #ff1a8d;
   */

   max-width: 300px;
   margin-left: 450px;
   margin-top: 100px;
   margin-bottom: 50px;
   padding: 10px;
   color: #FFF;
   font-family: sans-serif;
}

body {
    background-color: #2b2b2b
}
````