# 5- background - Parte 2

[link](http://cfbcursos.com.br/css3-4567-imagem-de-fundo-background-image/)

```css
p {

    padding: 30px 200px 30px 200px;

  /*  1 topo, 2 direita, 3 embaixo, 4 esquerda */
}
```


```css
p {
    border: 10px dotted #000;

   /* 1 grossura, 2 solid ou dotted e 3 cor */
}
```