# 8- bordas (border) - Parte 1

link: http://cfbcursos.com.br/css3-8-bordas-border/

```
#d1, #d2 {
    width: 300px;
    height: 300px;
    background-color: #8400ff;
    border-style: solid;
    border-width: 10px;
    border-color: #ffffff;
    border-radius: 20px;
}


ou também

    border: #fff solid 10px


```

1- Cor 2- Tipo 3- Tamanho