# 6- background - Parte 3

[link](http://cfbcursos.com.br/css3-4567-imagem-de-fundo-background-image/)

```css
body {
    background-image: url(Imagem2.jpg), url(Imagem.png);
    background-repeat: no-repeat, repeat;
    background-size: 400px, 400px;
    background-attachment: scroll, fixed;
}
```
